This demo uses the CCV Javascript Face Detection Library.

-------------------------------------------------------------------------------
To start run App.start()  in your console.

You can also pass it a few different effects:

*App.start('glasses'); // Goofy Glasses example

*App.start('green'); // Green Screen effect (there is a hidden max and min sliders you can use to adjust the thresholds)

*App.start('hipster'); // simple pixel manipulation example

*App.start('blur'); // blur example


Requires a browser that supports getUserMedia (Opera Labs camera or Chrome Canary)

Start Google Chrome Canary with open -a Google\ Chrome\ Canary --args --enable-media-stream  OR enable the flag in about:flags

--------------------------------------------------------------------------------

Original links with a stored local video: 

Demo Video: http://www.youtube.com/watch?v=YYES9Qd094o&hd=1

Working Demo : http://wesbos.com/demos/html5-face-detection/ 

Tutorial : http://www.wesbos.com/html5-video-face-detection-canvas-javascript
